package mini2;

import java.lang.*;
import java.util.ArrayList;

import java.awt.Point;
import java.util.Scanner;

import api.Converter;
import plotter.Polyline;

/**
 * Converts a string into a <code>Polyline</code> object.  The given 
 * string must conform to the format specified for one valid line of the file 
 * as described in Lab 8, checkpoint 2.  See
 * <pre>
 * http://web.cs.iastate.edu/~cs227/labs/lab8/page12.html
 * </pre>
 */
public class PolylineConverter implements Converter<Polyline>
{
	public Polyline convert(String str){
		Scanner scan = new Scanner(str);
		int width;
		int x, y;
		String color;
		ArrayList<Point> nu = new ArrayList<>();
		if(Character.isDigit(str.charAt(0)))
			width = scan.nextInt();
		else
			width = 1;
		color = scan.next();
		while(scan.hasNext()){
			//x
		}
		return null;
	}
}

//public class Point(int size
