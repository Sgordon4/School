package mini2;

import api.Combiner;

/**
 * Combiner that appends the first letter of a string onto
 * the accumulator.  If the string is empty, returns the 
 * accumulator.
 */
public class FirstLetterCombiner implements Combiner<String>
{
  public String combine(String obj, String str){
	  if(str.trim().length() == 0)
		  return obj;
	  return obj + str.charAt(0);
  }
}
