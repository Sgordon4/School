package hw1;

public class Cab {
	private double base, rate, totCash = 0, totMiles = 0, meter = 0;
	private boolean passenger = false;
	
	public Cab(double givenBase, double givenRate) {
		base = givenBase;
		rate = givenRate;
	}
	
	public double getTotalMiles(){ 	// Total miles with or without passenger
		return totMiles;
	}
	
	public double getTotalCash(){	// Builds between pickups and dropoffs
		return totCash;
	}
											/* Uses passenger */
	public double getCurrentRate(){	//Prints rate if passenger and 0 if not
		if (passenger)
			return rate;					
		return 0;
	}
	
	public double getMeter(){		//Prints (base fare) + (rate * miles driven w/
		return meter;				//	current passenger)
	}
											/* Uses passenger */
	public void drive(double miles){	//Adds to meter if passenger, adds to totMiles
		if (passenger)
			meter += miles * rate;
		totMiles += miles;
	}
	
	public void pickUp(){			//Changes meter to the base and sets passenger
		passenger = true;			//	to true for other methods
		meter = base;
	}
	
	public void dropOff(){			//Updates totCash, resets meter, and sets passenger
		passenger = false;			//	to false for other methods
		totCash += meter;
		meter = 0;
	}
	
	public double getAverageIncomePerMile(){	//Wanted with SpecCheck, gets avg
		return totCash/totMiles;				//	cash per mile
	}
	
	public boolean hasPassenger(){	//Needed by SpecCheck 
		return passenger;
	}
}
