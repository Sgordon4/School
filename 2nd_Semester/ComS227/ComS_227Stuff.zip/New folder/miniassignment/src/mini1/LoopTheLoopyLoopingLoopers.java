package mini1;
import java.util.Scanner;
/**
 * Try saying that five times fast.
 */
public class LoopTheLoopyLoopingLoopers
{

	/**
	 * Private constructor means this class cannot be instantiated.
	 */
	private LoopTheLoopyLoopingLoopers()
	{  
		// do nothing
	}


	/**
	 * Determines the number of iterations of Newton's method
	 * required to approximate the square root of x within
	 * the given bound.  Newton's method starts out by 
	 * setting the initial approximate <em>answer</em> to x.  
	 * Then in each iteration, <em>answer</em> is replaced by 
	 * the quantity <em>(answer + x / answer) / 2.0</em>.
	 * The process stops when the difference between 
	 * x and <em>(answer * answer)</em> is strictly less than
	 * the given bound <code>err</code>.  The method
	 * returns the number of iterations required.
	 * The given value x must be non-negative.
	 * <p>
	 * For example, given x = 10 the first three iterations
	 * of Newton's method produce the approximate values 
	 * 5.5, 3.66, and 3.20. Those three values squared are
	 * 30.29, 13.39, and 10.21, respectively.
	 * Therefore <code>countIterations(10, 1.0)</code>
	 * returns 3, since it takes 3 iterations to get the result 10.21
	 * that is within 1.0 of x.  
	 * On the other hand, <code>countIterations(10, 200)</code> returns 0,
	 * since 10 * 10 = 100 is already within 200 units of x = 10.
	 * @param x
	 *   value whose square root is to be approximated
	 * @param err
	 *   given bound for the approximation
	 * @return
	 *   number of iterations required to get an approximation
	 *   whose square is within the given bound of x
	 */
	public static int countIterations(double x, double err)
	{
		double answer = x;
		int count = 0;
		while(Math.abs(x-(answer*answer)) >= err){	/** Uses abs so the result is never negative and can be effectively compared to error*/
			answer = (answer+x/answer)/2;
			count++;
		}
		return count;
	}

	/**
	 * Returns a string with runs of consecutive characters removed.
	 * For example, <code>eliminateRuns("abbbccbbd")</code> returns 
	 * the string "abcbd".
	 * @param s
	 *   given string (possibly empty)
	 * @return
	 *   string similar to s but with runs removed
	 */
	public static String eliminateRuns(String s)
	{
		if(s.length() < 1)	/**Returns an empty string if s contains nothing*/
			return "";
		char current = s.charAt(0);
		String string = ""+s.charAt(0);		
		for(int i = 1; i < s.length(); i++){	/** Iterates through s*/
			if(current != s.charAt(i)){			/** Only adds to the string if the character is new*/
				current = s.charAt(i);
				string = string+current;
			}
		}
		return string;
	}

	/**
	 * Returns the second largest value in a list of numbers,
	 * where the list is given as a string of text containing integer
	 * values separated by arbitrary whitespace.  Duplicates are allowed, so
	 * the largest and second largest numbers may be the same; for example,
	 * given the string "17  137  42  137", the method returns 137. 
	 * The behavior is undefined if the provided string contains any 
	 * non-numeric values or contains fewer than two numbers.
	 * @param text
	 *   string of text containing at least two numbers separated by whitespace
	 * @return
	 *   second largest value in the string
	 */ 
	public static int findSecondLargest(String text)
	{
		Scanner scan = new Scanner(text);		/**Uses a scanner to iterate through the string*/
		int largoest = scan.nextInt(), largo = largoest,a;
		while(scan.hasNext()){					/**While there is another item ahead*/
			a = scan.nextInt();
			if(a >= largo){						/**If a > second largest*/
				largo = a;						/**Second largest = a*/
				if(a >= largoest){				/**If a >= largest*/
					largo = largoest;			/**Second largest = largest (allows for duplicates)*/
					largoest = a;				/**Largest = a*/
				}
			}
		}
		return largo;
	}

	/**
	 * Determines whether the given string of text represents a 
	 * <em>Lucas sequence</em>, where the given text consists of integer
	 * values separated by arbitrary whitespace.  A Lucas sequence
	 * is any sequence of numbers in which each value (other than
	 * the first and second) is the sum of the previous two values.
	 * The Fibonacci sequence is one example of a Lucas sequence.
	 * Another one would be "-2 1 -1 0 -1 -1 -2 -3 -5 -8".
	 * This method returns true if the sequence has fewer than 3 numbers.
	 * The behavior is undefined if the provided string contains any non-numeric
	 * values.
	 * @param text
	 *   string of text (possibly empty) containing numbers separated by whitespace
	 * @return
	 *   true if the given sequence of numbers is a Lucas sequence, 
	 *   false otherwise
	 */
	public static boolean isLucasSequence(String text)
	{
		if(text.length() < 3)					/**If text has 1 or fewer items it is mandated to return true*/
			return true;
		Scanner scan = new Scanner(text);		/**Uses a scanner to iterate through the string*/
		int sum = scan.nextInt(), a = scan.nextInt(), b = scan.nextInt();	/**Initializes these three variables with the first three items*/
		sum += a;
		while(scan.hasNext()){					/**While there is another item*/
			if(sum != b)						/**If the sum of n1 and n2 does not equal n3, return false*/
				return false;
			sum = sum+a;						/**Otherwise add to the sum*/
			a = b;								/**And shift the values over one*/
			b = scan.nextInt();
		}
		if(sum != b)							/**One final check to catch the last number, as otherwise this method would miss it*/
			return false;
		return true;
	}

	/**
	 * Returns the character that occurs most frequently in 
	 * the given string.  If several characters occur with 
	 * the same maximum frequency, returns the one that
	 * occurs first in the string.  The string must be nonempty.
	 * <p>
	 * For example, given the string "banana" the method returns 'a'.
	 * Given the string "abcbcbbcca" the method returns 'b'.
	 * @param s
	 *   nonempty string
	 * @return
	 *   most frequently occurring character in s
	 */
	public static char findMostFrequentCharacter(String s)
	{
		int[]arr  = new int[128];					/**Creates an array with space for every letter in ascii*/
													/**							--Setup for the loops--													*/
		int maxLoc = (int)s.charAt(0);				/**	Initializes maxLoc to the first character to avoid .indexOf returning -1						*/
		int maxCount = 1;							/**	Sets maxCount to 1 because there has only been one character checked, and it needs to exist		*/
		arr[(int)s.charAt(0)]++;					/** Adds one to the slot in the array representing the count for that character						*/
		
		for(int i = 1; i < s.length(); i++){		/**Iterates through the string*/
			
			/**Adds one to the count for that character, then checks if it is greater than the current max*/
			if(++arr[(int)s.charAt(i)] > maxCount){
				maxLoc = (int)s.charAt(i);			/**Updates the current max location in the array*/
				maxCount = arr[maxLoc];				/**Updates the current max*/
			}
			/**Checks to see if the new character came first if its new count equals the current max*/
			else if(arr[(int)s.charAt(i)] == maxCount && s.indexOf(s.charAt(i)) < s.indexOf((char)maxLoc))	
				maxLoc = (int)s.charAt(i);			/**Updates the current max location in the array*/
		}
		return (char)maxLoc;
	}

	/**
	 * Counts the number of times that one string occurs as a substring in
	 * another, optionally allowing the occurrences to overlap.  For
	 * example:
	 * <ul>
	 * <li><code>countOccurrences("aa", "aaaaa", false)</code> returns 2
	 * <li><code>countOccurrences("aa", "aaaaa", true)</code> returns 4
	 * <li><code>countOccurrences("aa", "ababab", true)</code> returns 0
	 * </ul>
	 * 
	 * @param t
	 *   string we are looking for ("target")
	 * @param s
	 *   string in which we are looking ("source")
	 * @param allowOverlap
	 *   true if occurrences of t are allowed to overlap
	 * @return
	 *   number of times t occurs in s as a substring
	 */
	public static int countOccurrences(String t, String s, boolean allowOverlap)
	{
		int count = 0, index = 0;
		index = s.indexOf(t); /**Nifty java function to return -1 or the first index of t within s*/
		
		while(index < s.length() && index != -1){ 	/**Ensures we don't search out of bounds*/
			count++;
			if(allowOverlap)
				index++;							/**If the call allows overlap, only adds one to the index to search from*/
			else
				index += t.length();				/**If the call does not allow overlap, add the length of the string we're searching for to index*/
			index = s.indexOf(t, index);
		}
		return count;
	}

	/**
	 * Merges two strings together, using alternating characters from each,
	 * except that runs of the same character are kept together.  For example,
	 * <ul>
	 * <li><code>mergePreservingRuns("abcde", "xyz") returns "axbyczde"
	 * <li><code>mergePreservingRuns("abbbbcde", "xyzzz") returns "axbbbbyczzzde"
	 * </ul>
	 * Either or both of the strings may be empty.  If the first string
	 * is nonempty, its first character will be first in the returned string.
	 * @param t
	 *   first string
	 * @param s
	 *   second string
	 * @return
	 *   string obtained by merging characters from t and s, preserving runs
	 */
	public static String mergePreservingRuns(String t, String s)
	{
		int index1 = 0, index2= 0;
		String str = "";
		char current = ' ';
		
		while(index1 < t.length() || index2 < s.length()){		/**While one of the indexes is smaller than its respective words length*/
			while(index1 < t.length()){							/**Checking if there is still more of t to parse through*/
				current = t.charAt(index1);						/**If so, sets the current character to current*/
				str += current;									/**Adds the character to str*/
				if(++index1 == t.length() || current != t.charAt(index1))	/**Increments index, and checks if it is less than its strings length to prevent oob errors*/
					break;										/**Then checks if the current character is not the same as the next, representing the end of a run. If so, breaks the loop*/
			}
			while(index2 < s.length()){							/**Checking if there is still more of s to parse through*/
				current = s.charAt(index2);						/**If so, sets the current character to current*/
				str += current;									/**Adds the character to str*/
				if(++index2 == s.length() || current != s.charAt(index2))	/**Increments index, and checks if it is less than its strings length to prevent oob errors*/
					break;										/**Then checks if the current character is not the same as the next, representing the end of a run. If so, breaks the loop*/
			}
		} 
		return str;
	}

	/**
	 * Separates s into two strings, each made of alternating characters
	 * from s, except that runs of the same character are kept together.
	 * The two strings are concatenated with a space between them to make
	 * a single returned string. If the given string is empty, the returned 
	 * string is a single space.
	 * For example,
	 * <ul>
	 * <li><code>takeApartPreservingRuns("abcdefa")</code> returns "acea bdf"
	 * <li><code>takeApartPreservingRuns("aabcccddddefa")</code> returns "aaccccea bddddf"
	 * </ul>
	 * @param s
	 *   any string
	 * @return
	 *   pair of strings obtained by taking alternating characters from s, 
	 *   keeping runs of the same character together, concatenated with 
	 *   one space between them into a single string 
	 */
	public static String takeApartPreservingRuns(String s)
	{
		boolean which = true;			/**Used to determine which strin to check*/
		String str1 = "", str2 = "";
		char current = ' ';
		int i = 0;
		
		while(i < s.length()){									/**While i is less than the length of s*/
			current = s.charAt(i);								/**Sets the current character to current*/
			if(which)	
				str1 += current;								/**If this is the string to check, adds the current character to string*/
			else
				str2 += current;								/**If this is the string to check, adds the current character to string*/
			
			if(++i < s.length() && current != s.charAt(i))		/**I want to increment i here for MAXIMUM EFFICIENCY allowed by my tired ass*/
				which = !which;									/**The first conditional in that if statement stops an out of bounds error*/
		}
		return str1 + " " + str2;
	}

}













