package hw3;


import api.Direction;

public class GameTest {
	public static void main(String[] args){
		GameUtil util = new GameUtil();
		int[] test = {3, 0, 1, 2};
		util.shiftArray(test);
		//System.out.println(Arrays.toString(test)); // expected [3, 1, 2, 0]
		
		int[] test2 = {3, 1, 1, 6};
		util.shiftArray(test2);
		//System.out.println(Arrays.toString(test2)); // expected [3, 1, 1, 6]
		
		int[] test3 = {1, 2, 1, 2};
		util.shiftArray(test3);
		//System.out.println(Arrays.toString(test3)); // expected [3, 1, 2, 0]
		
		Game game = new Game(4, util);
		for(int x = 0; x < game.getSize(); x++){
			for(int y = 0; y < game.getSize(); y++){
				game.setCell(x,y,0);
			}
		}
		game.setCell(0,1,2);
		game.setCell(1,1,4);
		game.setCell(3,1,8);
		//int[] array = game.copyRowOrColumn(1, Direction.DOWN);
		//System.out.println(Arrays.toString(array));
		
		game.PrintArraysForTest();
		System.out.println("\n");
		System.out.println("\n");
		System.out.println("Starter Arrays ^^");
		System.out.println("\n");
		System.out.println("\n");
		System.out.println("\n");
		game.shiftGrid(Direction.LEFT);
		System.out.println("----LEFT----");
		game.PrintArraysForTest();
		game.shiftGrid(Direction.UP);
		System.out.println("----UP----");
		game.PrintArraysForTest();
		game.shiftGrid(Direction.RIGHT);
		System.out.println("----RIGHT----");
		game.PrintArraysForTest();
		game.shiftGrid(Direction.DOWN);
		System.out.println("----DOWN----");
		game.PrintArraysForTest();
		game.shiftGrid(Direction.RIGHT);
		System.out.println("----RIGHT----");
		game.PrintArraysForTest();
		game.shiftGrid(Direction.RIGHT);
		System.out.println("----RIGHT----");
		game.PrintArraysForTest();
		game.shiftGrid(Direction.UP);
		System.out.println("----UP----");
		game.PrintArraysForTest();
		game.shiftGrid(Direction.LEFT);
		System.out.println("----LEFT----");
		game.PrintArraysForTest();
		game.shiftGrid(Direction.UP);
		System.out.println("This is where it should be");
		System.out.println("----UP----");
		game.PrintArraysForTest();
		System.out.println("\n----------------------\n");
		System.out.println("\n----------------------\n");
		System.out.println("\n----------------------\n");
		game.shiftGrid(Direction.LEFT);
		System.out.println("\n----------------------\n");
		game.shiftGrid(Direction.LEFT);
		System.out.println("\n----------------------\n");
		game.undo();
		System.out.println("\n----------------------\n");
		game.PrintArraysForTest();
		System.out.println("TEST");
		System.out.println("\n----------------------\n");
		game.shiftGrid(Direction.DOWN);
		System.out.println("\n----------------------\n");
		game.PrintArraysForTest();
		System.out.println("TEST");
		System.out.println("\n----------------------\n");
		game.shiftGrid(Direction.UP);
		System.out.println("\n----------------------\n");
		game.PrintArraysForTest();
		System.out.println("TEST");

	}
}