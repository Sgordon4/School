package hw2;

/**
* Simplified model of American baseball.
* 
* THIS CODE WILL NOT COMPILE UNTIL YOU HAVE ADDED STUBS FOR 
* ALL METHODS SPECIFIED IN THE JAVADOC
* 
* @author Sean Gordon
*/
public class CS227Baseball
{
	/**Constant indicating that a pitch results in a ball.*/
	public static final int BALL = 0;
	
	/**Constant indicating that a pitch results in a strike.*/
	public static final int STRIKE = 1;
	
	/**Constant indicating that a pitch results in an out from a fly ball.*/
	public static final int POP_FLY = 2;
	
	/**Number of strikes causing a player to be out.*/
	public static final int MAX_STRIKES = 3;
	  
	/**Number of balls causing a player to walk.*/
	public static final int MAX_BALLS = 4;
	  
	/**Number of outs before the teams switch.*/
	public static final int MAX_OUTS = 3;
	
	/**Counts current inning.*/
	private int inning = 1;
	/**Set in constructor to find when the game is over.*/
	private int totalInnings;
	/**Boolean  to keep tract of the current half of the inning.*/
	private boolean top = true;
	/**Counts number of balls current batter has accumulated.*/
	private int balls = 0;
	/**Counts number of strikes current batter has accumulated.*/
	private int strikes = 0;
	/**Counts number of outs current batter has accumulated.*/
	private int outs = 0;
	/**Variables to keep track of the scores of the two teams.*/
	private int score1 = 0, score2 = 0;
	/**Booleans to keep tack of which bases are occupied.*/
	private boolean p1st = false, p2nd = false, p3rd = false;
	/**Used as a temp var to remove score in pitchWithHitAndOut().*/
	private boolean pHome = false;
	
	// TODO: everything else
	/**Constructs a game that has the given number of innings and starts at the top of inning 1.*/
	public CS227Baseball(int givenNumInnings){
		  totalInnings = givenNumInnings;
	}
	/**Advances all players on base by one base, updating the score if there is currently a player on third.*/
	public void advanceRunners(boolean newPlayerOnFirst){
		if(p3rd){
			if(top)
				score1++;
			else
				score2++;
		}
		pHome = p3rd;
		p3rd = p2nd;
		p2nd = p1st;
		p1st = newPlayerOnFirst;
	}
	/**Returns the number of balls for the current batter.*/
	public int getBalls(){
		return balls;
	}
	/**Returns the current inning.*/
	public int getInning(){
		return inning;
	}
	/**Returns the number of outs for the current batter.*/
	public int getOuts(){
		return outs;
	}
	/**Returns the score of the team requested.*/
	public int getScore(boolean team0){
		if(team0)
			return score1;
		else
			return score2;
	}
	/**Returns the strikes accumulated by the current batter.*/
	public int getStrikes(){
		return strikes;
	}
	/**Returns if the game is over based on the current inning.*/
	public boolean isOver(){
		return false;
	}
	/**Returns the current half of the current inning.*/
	public boolean isTop(){
		return top;
	}
	/**Used to signify a pitch without a hit or an out.*/
	public void pitch(int outcome){
		switch(outcome){
			case 0:	balls++;
			break;
			case 1: strikes++; if(strikes == 3){strikes = 0; balls = 0; outs++;};
			break;
			case 2: strikes = 0; balls = 0; outs++;
			break;
		}
		if(outs == 3){
			if(!top)
				inning++;
			top = !top;
			outs = 0;
		}
	}
	/**Used to signify a pitch with a hit.*/
	public void pitchWithHit(int numBaases){
		advanceRunners(true);
		for(int i = 0; i < numBaases-1; i++){
			advanceRunners(false);
		}
	}
	/**Used to signify a pitch with a hit and an out.*/
	public void pitchWithHitAndOut(int numBases, int whichBasefielded){
		advanceRunners(true);
		for(int i = 0; i < numBases-1; i++){
			advanceRunners(false);
		}
		switch(whichBasefielded){
			case 1: if(p1st){p1st = false; outs++;}
			break;
			case 2: if(p2nd){p2nd = false; outs++;}
			break;
			case 3: if(p3rd){p3rd = false; outs++;}
			break;
			case 4: 
				if(pHome){
					pHome = false; 
					outs++;
					if(top)
						score1--;
					else
						score2--;}
			break;
		}
	}
	/**Used to check if there is a player on first.*/
	public boolean playerOnFirst(){
		return p1st;
	}
	/**Used to check if there is a player on second.*/
	public boolean playerOnSecond(){
		return p2nd;
	}
	/**Used to check if there is a player on third.*/
	public boolean playerOnThird(){
		return p3rd;
	}
	
	
	/**
	* Returns a three-character string representing the players on base, 
	* in the order first, second, and third, where 'X' indicates a player 
	* is present and 'o' indicates no player.  For example, the string "XXo" 
	* means that there are players on first and second but not on third.
	* @return
	*   three-character string showing players on base
	*/
	public String getBases(){
		return (playerOnFirst() ? "X" : "o") +
				(playerOnSecond() ? "X" : "o") +
				(playerOnThird() ? "X" : "o");
	}
	
	/**
	* Returns a one-line string representation of the current game state.
	* The format is:
	* <pre>
	*    ooo Inning:1 (T) Score:0-0 Balls:0 Strikes:0 Outs:0
	* </pre>
	* The first three characters represent the players on base as returned by 
	* the <code>getBases()</code> method. The 'T' after the inning number indicates 
	* it's the top of the inning, and a 'B' would indicate the bottom.
	* 
	* @return
	*   one-line string representation of the game state
	*/
	public String toString(){
		String bases = getBases();
		String topOrBottom = (isTop() ? "T" : "B");
		String fmt = "%s Inning:%d (%s) Score:%d-%d Balls:%d Strikes:%d Outs:%d";
		return String.format(fmt, bases, getInning(), topOrBottom, getScore(true), getScore(false), getBalls(), getStrikes(), getOuts());
	}
	
	/**
	* Returns a multi-line string representation of the current game state.
	* The format is:  
	* <pre>
	*     o - o    Inning:1 (T)
	*     |   |    Score:0-0
	*     o - H    Balls:0 Strikes:0 Outs:0
	* </pre>
	* The 'T' after the inning number indicates it's the top of the inning, 
	* and a 'B' would indicate the bottom.
	* @return
	*   multi-line string representation of current game state
	*/
	public String toDisplayString(){
		String firstChar = (playerOnFirst() ? "X" : "o");
		String secondChar = (playerOnSecond() ? "X" : "o");
		String thirdChar = (playerOnThird() ? "X" : "o");
		String topOrBottom = (isTop() ? "T" : "B");
		String firstLine = String.format("%s - %s    Inning:%d (%s)\n", secondChar, firstChar, getInning(), topOrBottom);
		String secondLine = String.format("|   |    Score:%d-%d\n", getScore(true), getScore(false));
		String thirdLine = String.format("%s - H    Balls:%d Strikes:%d Outs:%d\n", thirdChar, getBalls(), getStrikes(), getOuts());
		return firstLine + secondLine + thirdLine;   
	}  
}