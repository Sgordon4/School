package hw4;

import java.awt.Color;

import api.Position;
import api.Cell;
import api.Block;

public class TShape extends AbstractShape{

	/** Initializes the array of cells that represent this shape
	 * @param givenPosition
	 * @param magic */
	public TShape(Position givenPosition, boolean magic){
		makeCell(4);

		setPos(givenPosition);
		Position p0 = new Position(getPos().row() -1, getPos().col());
		Position p2 = new Position(getPos().row(), getPos().col() -1);
		Position p3 = new Position(getPos().row(), getPos().col() +1);

		setCell(0, new Cell(new Block(Color.MAGENTA, magic), p0));
		setCell(1, new Cell(new Block(Color.MAGENTA, false), p2));
		setCell(2, new Cell(new Block(Color.MAGENTA, false), getPos()));
		setCell(3, new Cell(new Block(Color.MAGENTA, false), p3));
	}
}