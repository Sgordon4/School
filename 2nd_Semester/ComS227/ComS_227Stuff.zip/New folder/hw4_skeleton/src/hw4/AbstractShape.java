
package hw4;

import api.Block;
import api.Cell;
import api.Position;
import api.Shape;

/**
 * Abstract superclass for implementations of the Shape interface.
 */
public abstract class AbstractShape implements Shape
{
	private Cell[] shape;
	private Position position = new Position(0, 0); //COM position
	
	protected void makeCell(int size){
		shape = new Cell[size];
	}
	
	protected Cell getCell(int index){
		return shape[index];
	}
	
	protected Position getPos(){
		return position;
	}
	
	protected void setCell(int index, Cell cell){
		shape[index] = cell;
	}
	
	protected void setPos(Position pos){
		position = pos;
	}
	
	public Cell[] getCells(){
		Cell[] copy = new Cell[shape.length];
		for(int i = 0; i < shape.length; i++)
			copy[i] = new Cell(shape[i]);

		return copy;
	}
	
	
	public void shiftDown(){
		position.setRow(position.row() + 1);
		for(Cell d: shape){
			d.setRow(d.getRow()+1);
		}
	}
	
	public void shiftLeft(){
		position.setCol(position.col() - 1);
		for(Cell d: shape){
			d.setCol(d.getCol()-1);
		}
	}

	public void shiftRight(){
		position.setCol(position.col() + 1);
		for(Cell d: shape){
			d.setCol(d.getCol()+1);
		}
	}
	
	public void cycle(){		
		Block temp = shape[shape.length-1].getBlock();
		for(int i = shape.length-1; i > 0; i--){
			shape[i].setBlock(shape[i-1].getBlock());
		}
		shape[0].setBlock(temp);
	}
	
	
	public void transform(){
		int tempR;
		int tempC;

		for(Cell d: shape){
			tempR = d.getRow() - position.row();
			tempC = d.getCol() - position.col();

			d.setRow(tempC * -1 + position.row());
			d.setCol(tempR + position.col());
		}
	}
	
	
	
	/** @return the array of cells that represent this shape */
	@Override
	public Shape clone()
	{
		try
		{
			AbstractShape s = (AbstractShape) super.clone();
			
			s.shape = new Cell[shape.length];

			s.position = new Position(position);		//Transfer to deep copy
			for(int i = 0; i < shape.length; i ++)		//
				s.shape[i] = new Cell(shape[i]);		//

			return s;
		}
		catch (CloneNotSupportedException e)
		{
			// can't happen
			return null;
		}
	}
}