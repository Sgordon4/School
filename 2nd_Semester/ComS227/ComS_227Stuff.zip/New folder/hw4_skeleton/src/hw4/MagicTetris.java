
package hw4;

import java.util.List;
import java.util.ArrayList;

import api.AbstractGame;
import api.Position;

/**
 * MagicTetris implementation.
 */
public class MagicTetris extends AbstractGame
{
	/**
	 * Constructs a game with the given width (columns) and height (rows).
	 * This game will use a new instance of BasicGenerator to 
	 * generate new shapes.
	 * @param width
	 *   width of the game grid (number of columns)
	 * @param height
	 *   height of the game grid (number of rows)
	 */
	private int tempMagic = 0, maxMagic = 0, totMagic = 0;

	public MagicTetris(int width, int height)
	{
		super(width, height, new BasicGenerator());
	}

	@Override
	public List<Position> determinePositionsToCollapse()
	{
		List<Position> pos =  new ArrayList<Position>();
		List<Position> temp =  new ArrayList<Position>();
		boolean open = false;

		//For loop to find any completed rows
		for(int r = getHeight()-1; r >= 0; r--){
			for(int c = getWidth() -1; c >= 0; c--){
				
				if(getBlock(r,c) != null){
					temp.add(new Position(r,c));
					if(getBlock(r,c).isMagic())
						tempMagic++;
				}
				else{
					temp.clear();
					tempMagic = 0;
					break;
				}	
			}
			
			totMagic += tempMagic;
			if(tempMagic > maxMagic)
				maxMagic = tempMagic;
			tempMagic = 0;
				
			pos.addAll(temp);
			temp.clear();
		}
		if(pos.size() != 0){
			return pos;
		}


		if(maxMagic > 2){
			maxMagic = 0;
			for(int c = 0; c < getWidth(); c++){
				for(int r = 0; r < getHeight(); r++){
					if(open && getBlock(r,c) == null)
						pos.add(new Position(r,c));
					else if(getBlock(r,c) != null)
						open = true;
				}
			open = false;
			}
		}
		return pos;

	}

	@Override
	public int determineScore()
	{
		return totMagic;
	}

}
