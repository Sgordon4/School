package hw4;

import java.awt.Color;

import api.Position;
import api.Cell;
import api.Block;

public class LShape extends AbstractShape{

	/** Initializes the array of cells that represent this shape
	 * @param givenPosition
	 * @param magic */
	public LShape(Position givenPosition, boolean magic){
		makeCell(4);

		setPos(givenPosition);
		Position p1 = new Position(getPos().row() +1, getPos().col() -2);
		Position p2 = new Position(getPos().row() +1, getPos().col() -1);
		Position p3 = new Position(getPos().row() +1, getPos().col());

		setCell(0, new Cell(new Block(Color.ORANGE, magic), getPos()));
		setCell(1, new Cell(new Block(Color.ORANGE, false), p1));
		setCell(2, new Cell(new Block(Color.ORANGE, false), p2));
		setCell(3, new Cell(new Block(Color.ORANGE, false), p3));
	}
	
}