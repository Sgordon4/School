
package hw4;

import java.util.*;

import api.Generator;
import api.Position;
import api.Shape;


/**
 * Generator for Shape objects in MagicTetris.  All six shapes
 * are equally likely, and the generated shape is magic with
 * 20% probability.
 */
public class BasicGenerator implements Generator
{
  @Override
  public Shape getNext(int width)
  {
	  boolean magic = false;
	  Random rand = new Random();
	  if(rand.nextInt(5) == 0)
		  magic = true;
	  
	  switch((rand.nextInt(6))) {
	  case 0: return new LShape(new Position(-1, width/2 +1), magic);
	  case 1: return new JShape(new Position(-1, width/2), magic);
	  case 2: return new IShape(new Position(-2, width/2), magic);
	  case 3: return new OShape(new Position(-1, width/2), magic);
	  case 4: return new TShape(new Position(0, width/2), magic);
	  case 5: return new SZShape(new Position(-1, width/2), magic);
	  }
	  return null;
  }
}
