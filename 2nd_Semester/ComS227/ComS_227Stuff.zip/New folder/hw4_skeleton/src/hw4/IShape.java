package hw4;

import java.awt.Color;

import api.Position;
import api.Cell;
import api.Block;

public class IShape extends AbstractShape{

	/** Initializes the array of cells that represent this shape
	 * @param givenPosition
	 * @param magic */
	
	public IShape(Position givenPosition, boolean magic){
		makeCell(3);

		setPos(givenPosition);
		Position p1 = new Position(getPos().row() +1, getPos().col());
		Position p2 = new Position(getPos().row() +2, getPos().col());

		setCell(0, new Cell(new Block(Color.CYAN, magic), getPos()));
		setCell(1, new Cell(new Block(Color.CYAN, false), p1));
		setCell(2, new Cell(new Block(Color.CYAN, false), p2));
	}
}