package hw4;

import java.awt.Color;

import api.Position;
import api.Cell;
import api.Block;

public class OShape extends AbstractShape{

	/** Initializes the array of cells that represent this shape
	 * @param givenPosition
	 * @param magic */
	public OShape(Position givenPosition, boolean magic){
		makeCell(4);

		setPos(givenPosition);
		Position p1 = new Position(getPos().row(), getPos().col() + 1);
		Position p2 = new Position(getPos().row() +1, getPos().col());
		Position p3 = new Position(getPos().row() +1, getPos().col() + 1);

		setCell(0, new Cell(new Block(Color.YELLOW, magic), getPos()));
		setCell(1, new Cell(new Block(Color.YELLOW, false), p1));
		setCell(2, new Cell(new Block(Color.YELLOW, false), p2));
		setCell(3, new Cell(new Block(Color.YELLOW, false), p3));
	}
	
	@Override
	public void transform(){
	}
}
