import java.util.*;

public class Test {
	public static void main(String[] args){
		int a = 42;
		String A = "SKAuTz".toLowerCase();
		A = A+a;
		System.out.println(A.charAt(6));

		String test =   "Hello, world!";

		for(int i = 0; i < test.length(); i++){
			if(!Character.isAlphabetic(test.charAt(i)))
				test = test.replace(test.charAt(i),'#');
		}
		System.out.println(test);

		ArrayList<Integer> arr = new ArrayList<Integer>();
		arr.add(1);
		arr.add(2);
		arr.add(3);
		arr.add(3);
		arr.add(3);
		arr.add(3);

		if(arr.get(2) < arr.get(3))
			System.out.println("Yes");

		int replace;
		int[] ints = {1,2,3,4,5,6,7,8,9,10};
		for(int i = 0; i < ints.length/2; i++){
			replace = ints[i];
			ints[i] = ints[ints.length - i-1];
			ints[ints.length - i - 1] = replace;
		}
		System.out.println(Arrays.toString(ints));

		String word="howdyw";
		for (int i = 0; i < word.length(); i++) {
			int count=0;
			for (int j = i+1; j < word.length(); j++) {
				if (word.charAt(i)==word.charAt(j)){
					count++;
				}
			}
			if (count>0){
				System.out.println("true");
			}
			else
				System.out.println("false");
		}


		
		System.out.println("\n\n");
		
		String vowels = "aeiouy";
		String loweredWord = "AjahkAhKeejAoHkAHkj";
		loweredWord = loweredWord.toLowerCase();

	    for (int index = 0; index < loweredWord.length(); index++)
	    {
	        if (vowels.contains(String.valueOf(loweredWord.charAt(index))))
	        {
	        	System.out.println(index);
	        }
	        else
		    	System.out.println("No my boy");
	    }

	    // handle cases where a vowel is not found
	    
	    System.out.println("\n\n");
	    
	    int[] ar = {1,2,3,3,5,4,6,8,7,7,5};
	    ArrayList<Integer> al = new ArrayList<Integer>();
	    for(int i = 0; i < ar.length; i++)
	    	al.add(ar[i]);
	    
	    int index = 0;
	    for(index = index; 
	    
	}
}
