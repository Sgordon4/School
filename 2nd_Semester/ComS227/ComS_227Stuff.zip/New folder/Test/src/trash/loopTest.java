package trash;

import static trash.LoopTheLoopyLoopingLoopers.*;

public class loopTest {
	public static void main(String[] args){
		System.out.println("hrgdjewidhwekbfke");
		System.out.println(countIterations(10, 1.0));							//3
		System.out.println(countIterations(10, 200));							//0
		System.out.println(eliminateRuns("abbbccbbd"));							//abcbd
		System.out.println(findSecondLargest("17 137 42 137"));					//137
		System.out.println(isLucasSequence("-2 1 -1 0 -1 -1 -2 -3 -5 -8"));		//true
		System.out.println(isLucasSequence("-2 1 -1 0 4 -1 -1 -2 -3 -5 -8"));	//false
		System.out.println(findMostFrequentCharacter("banana"));				//a
		System.out.println(findMostFrequentCharacter("abcbcbbcca"));			//b
		//System.out.println(countOccurrences("aa", "aaaaa", false));				//2
		//System.out.println(countOccurrences("aa", "aaaaa", true));				//4
		//System.out.println(countOccurrences("aa", "ababab", true));				//0
		System.out.println(mergePreservingRuns("abcde", "xyz"));				//axbyczde
		System.out.println(mergePreservingRuns("abbbbcde", "xyzzz"));			//axbbbbyczzzde
		System.out.println(takeApartPreservingRuns("abcdefa"));					//acea bdf
		System.out.println(takeApartPreservingRuns("aabcccddddefa")); 			//aacccea bddddf	On the javadoc it states the result should be aa*cccc*ea bddddf but I think it's a typo
																				//					You only start with three c's in a row:		 aab*ccc*ddddefa
		System.out.println(findSecondLargest("42 137 -7 42 66 55"));
		System.out.println(isLucasSequence("1 1 2 3 5 8 14"));
		System.out.println(findMostFrequentCharacter("cabababcbabacc"));
		
	}
}	