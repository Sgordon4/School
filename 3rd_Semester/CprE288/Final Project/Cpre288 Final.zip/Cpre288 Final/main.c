/**
 * main.c Main program
 *
 * @author SGordon4, CPhilipp, MSolaro, EStablein
 * @date 12/1/2018
 */

#include "limits.h"     //Used to initialize min to INT_MAX in part 2, not super needed
#include "math.h"       //Used to calculate cosine of an angle in part 2

#include "button.h"
#include "cyBot_uart.h" // Functions for communiticate between CyBot and Putty (via UART)
#include "open_interface.h"
/*
#include <stdint.h>
#include "timer.h"
#include "lcd.h"
#include <stdbool.h>
#include "driverlib/interrupt.h"
 */
#include <SCping.h>
#include <ir.h>
#include <servo.h>
#include <movement.h>
#include <uart.h>

#include "cyBot_uart.h" // Functions for communiticate between CyBot and Putty (via UART)
// PuTTy: Buad=115200, 8 data bits, No Flow Control, No Party,  COM1
#include "cyBot_Scan.h" // For scan sensors






void finalAlg();
void scan();
int checkBoundaries(oi_t *sensor_data);
void testSCPing();
void testSCSensors();
void testSCservo();
void testCliffStuff();

#define NUM_TEST 0       //0 = part1, 1 = part2, etc...


int main(void){


    switch(NUM_TEST){
    case 0: finalAlg();
    break;
    case 1: testSCPing();
    break;
    case 2: testSCSensors();
    break;
    case 3: testSCservo();
    break;
    case 4: testMovement();
    break;
    case 5: testCliffStuff();
    break;
    }
}

/**
* This is the function to call to run the final project code.
* @author SGordon4, CPhilipp, MSolaro, EStablein
* @date 12/1/2018
*/
void finalAlg(){
    uart_init();
    ping_init();
    ADC_init();
    lcd_init();
    servo_init();

    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
    char command;


    while(1){
        command = (char)uart_receive();

        int distanceToGo = 15;
        int speed = 150;

        switch(command){
        //Forward up down left right
        case 'f':
        {


            int i = 0;
            command = 'R';
            for(i = 0; i < 6; i++){
                char oof = checkBoundaries(sensor_data);
                if(!oof){
                    forward(sensor_data, speed, distanceToGo);        //Max 9
                }
                else{
                    backward(sensor_data, speed, distanceToGo*(i+1));
                    command = oof;
                    //TODO Do something here, send some data back or something
                    break;
                }
            }
        }
        break;
        //forward on a diagonal
        case 'F':
        {
            int i = 0;
            command = 'R';
            for(i = 0; i < 4; i++){
                char oof = checkBoundaries(sensor_data);
                if(!oof){
                    forward(sensor_data, speed, distanceToGo);        //Max 12
                }
                else{
                    backward(sensor_data, speed, distanceToGo*(i+1));
                    command = oof;
                    //TODO Do something here, send some data back or something
                    break;
                }
            }
        }
        break;
        //Left
        case 'l': left(sensor_data, 150, 45);
        command = 'R';
        break;
        //Backward
        case 'b': backward(sensor_data, 250, 100);
        command = 'R';
        break;
        //Right
        case 'r': right(sensor_data, 150, 45);
        command = 'R';
        break;
        //Scan
        case 's': command = 255;
        scan();
        break;
        }

        stop();
        uart_sendChar(command);
        timer_waitMillis(200);
    }
}

/**
* This method scans with the sensors and returns an array of found objects to the UI
* @author SGordon4, MSolaro
* @date 12/1/2018
*/
void scan(){
    double ping_dist = 0;

    float voltage = 0;
    double ir_dist = 0;

    int degrees = 0;
    int increment = 1;

    char scanData[180 + 1];         //Max 180 (degrees)
    scanData[180] = 0;              //JIC

    turnDegrees(degrees);
    timer_waitMillis(1000);

    while(degrees < 180){
        turnDegrees(degrees);
        timer_waitMillis(10);
        //TODO
        ping_dist = getPingDistance();    //Seems to be slightly too large a distance at range

        voltage = ADC_read2(0);
        ir_dist = IR_Convert(voltage);

        if(ir_dist < 54){
            scanData[(int)(degrees/increment)] = (char)ping_dist;
        }else{
            scanData[(int)(degrees/increment)] = '_';
        }

        degrees += increment;
    }
    //uart_sendChar('S');

    int i = 0;
    for (i = 0; i < strlen(scanData) - 1; i++)
    {
        uart_sendChar(scanData[i]);
    }

}

/**
* This method checks if a sensor (like a bump sensor) has been tripped.
* @author SGordon4, CPhilipp, MSolaro, EStablein
* @date 12/1/2018
*/
int checkBoundaries(oi_t *sensor_data){
    char cliffs[5];         //Only needs to be 4, put as 5 to print it
    int boundaries[4];
    char bumpers[2];

    cliffDetector(sensor_data, cliffs);
    cliffColorDetector(sensor_data, boundaries);
    bumpDetector(sensor_data, bumpers);

    int i;
    for(i = 0; i < 4; i++){
        if(cliffs[i])
            return i + 1;
    }
    for(i = 0; i < 4; i++){
        if(boundaries[i] > 2650)
            return i + 5;
    }
    for(i = 0; i < 2; i++){
        if(bumpers[i])
            return i + 9;
    }

    //returns 1-10 corresponding to whatever is triggered
    //or 0 if nothing is

    return 0;
}


//----------------- UNUSED -----------------//
void testSCPing(){
    ping_init();
    lcd_init();

    double ping_dist = 0;
    while(1){
        ping_dist = getPingDistance();
        lcd_printf("Distance: %.3lf", ping_dist);
        timer_waitMillis(500);
    }

}

//----------------- UNUSED -----------------//
void testSCSensors(){
    ping_init();
    ADC_init();
    lcd_init();

    double ping_dist = 0;

    float voltage = 0;
    double ir_dist = 0;


    ping_dist = getPingDistance() * .98;    //Seems to be slightly too large a distance at range


    voltage = ADC_read2(0);
    ir_dist = IR_Convert(voltage);

    //ir_dist = read_dist2();

    lcd_printf("Ping Distance: %.3lf\nIR Distance: %.3lf", ping_dist, ir_dist);
    timer_waitMillis(500);


}

//----------------- UNUSED -----------------//
void testSCservo(){
    servo_init();
    lcd_init();

    int degrees = 0;
    int direction = 1;

    turnDegrees(degrees);
    timer_waitMillis(1000);


    while(1){
        degrees += direction;

        turnDegrees(degrees);
        timer_waitMillis(5);

        if(degrees == 0 || degrees == 180)
            direction *= -1;
    }
}

//----------------- UNUSED -----------------//
void testCliffStuff(){
    lcd_init();
    uart_init();

    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
    char cliffs[5];
    int boundaries[4];

    while(1){
        cliffDetector(sensor_data, cliffs);
        printCliffs(cliffs);

        cliffColorDetector(sensor_data, boundaries);

        lcd_printf("%s\n%d %d %d %d", cliffs, boundaries[0], boundaries[1], boundaries[2], boundaries[3]);

        timer_waitMillis(200);
    }

}























