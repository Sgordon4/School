/**
 * SCping.c
 *
 * Ping sensor file for CprE288
 *
 * @author SGordon4, CPhilipp, MSolaro, EStablein
 * @date 11/5/2018
 */
#include <SCping.h>
#include "timer.h"
#include "driverlib/interrupt.h"        //Includes interrupt functions (IntRegister, IntMasterEnable, ...)

/**
* This method initializes the ping sensor.
* @author SGordon4, CPhilipp, MSolaro, EStablein
* @date 11/5/2018
*/
void ping_init()
{
    SYSCTL_RCGCGPIO_R |= 0b00000010;    //Enable clock to GPIO port B

    GPIO_PORTB_DIR_R |= 0xF7;           //Set pin 3 to output
    GPIO_PORTB_DEN_R |= 0b00001000;     //Set pin 3 to digital    0xFF

    /*---------------------------------------------------------*/
    /*                   Initializes Timer3B                   */
    /*---------------------------------------------------------*/


    SYSCTL_RCGCTIMER_R |= 0x8;          //Enable clock to GPIO port B

    TIMER3_CTL_R &= ~0x100;             //Disable timer3B

    TIMER3_CTL_R &= 0xFFFF90FF;         //Clear timer b configs

    TIMER3_CFG_R &= 0xFFFFFFF8;         //Clearing bits 2:0
    TIMER3_CFG_R |= 0x4;                //Setting timer to 16 bit mode

    TIMER3_TBMR_R &= 0xFFFFF000;        //Clearing bytes 2:0
    TIMER3_TBMR_R |= 0x017;             //Setting TBMR configs          37?
    //Capture mode, Edge-Time mode, Up-Count

    TIMER3_TBILR_R = 0xFFFE;           //Set upper bound for timer      0xFFFE, doesn't use the extension thing with TIMER3_TBPS_R | Different number? | lec14_15 pg 36 | 0xFFFF = 65535 | If there is an overflow, add 65536 to num
    //                                                                                                                Last part in this: https://www3.nd.edu/~lemmon/courses/ee224/web-manual/web-manual/lab12/node3.html

    TIMER3_IMR_R &= 0xFFFEF0E0;         //Clearing all but RES bits
    TIMER3_IMR_R |= 0x00000400;         //Setting IMR configs           200?
    //GPTM Timer B Capture Mode Event Interrupt Mask
    //WUEIM interrupts are disabled, probably not a big deal

    TIMER3_CTL_R |= 0x00000D00;         //Re-enable TimerB              2100?
    //Positive and Negative edge, enable timer  0b1101

    TIMER3_IMR_R |= 0x700; //enable capture interrupts


    //NVIC Setup
    NVIC_PRI9_R |= 0x20;
    NVIC_EN1_R |= 0x10;

    IntRegister(INT_TIMER3B, TIMER3B_Handler); //Bind interrupt handle
    IntMasterEnable(); //enable global interrupts


    update_flag = 0;
}

/**
* This method initializes the ping input capture timer.
* @author SGordon4, CPhilipp, MSolaro, EStablein
* @date 11/5/2018
*/
void TIMER3B_Handler(){
    if(TIMER3_MIS_R &= 0x400){      //If bit 10, "GPTM Timer B Capture Mode Event Raw Interrupt" flag is set...
        switch(update_flag){
        case 0: start_time = TIMER3_TBR_R;  //Set first time
        update_flag = 1;                    //Update flag
        break;
        case 1: end_time = TIMER3_TBR_R;    //Set second time
        update_flag = 2;                    //Update flag
        break;
        }

        TIMER3_ICR_R |= 0x400;      //clear bit 10, "GPTM Timer B Capture Mode Event Raw Interrupt" flag using ICR reg
    }
}

//-------------------------------------------------------

/**
* This method pulses the ping sensor.
* @author SGordon4, CPhilipp, MSolaro, EStablein
* @date 11/5/2018
*/
volatile void sendPulse(){
    TIMER3_CTL_R &= ~0x100;         //Disable Timer3
    GPIO_PORTB_AFSEL_R &= ~0x8;     //Disable Alt function on bit 3
    GPIO_PORTB_PCTL_R &= ~0x7000;   //Disable to set pin to output



    GPIO_PORTB_DIR_R |= 0x08; // set PB3 as output
    GPIO_PORTB_DATA_R |= 0x08; // set PB3 to high
    timer_waitMicros(6);
    GPIO_PORTB_DATA_R &= 0xF7; // set PB3 to low
    GPIO_PORTB_DIR_R &= 0xF7; // set PB3 as input



    GPIO_PORTB_PCTL_R |= 0x7000;    //Re-enable as configurations are complete
    GPIO_PORTB_AFSEL_R |= 0x8;      //Enable Alt function on bit 3
    TIMER3_CTL_R |= 0x100;          //Enable Timer3

}


//-------------------------------------------------------
//                  Utility Functions
//-------------------------------------------------------

/**
* This method gets the distance the ping sensor reads.
* @author SGordon4, CPhilipp, MSolaro, EStablein
* @date 11/5/2018
*/
double getPingDistance(){
    sendPulse();

    while(update_flag != 2){        //Wait until start and end time have been recieved

    }
    update_flag = 0;

    int start = start_time;
    int end = end_time;
    int pulse = pulseLength;

    int overflow = (end_time < start_time) * 65536;         //Find if overflow has occurred
    pulseLength = end_time + (overflow) - start_time;       //Find length of pulse, adding possible overflow correction

    pulse = pulseLength;

    return pulseLength / 930.24;                            //Calculate distance in cm
}
