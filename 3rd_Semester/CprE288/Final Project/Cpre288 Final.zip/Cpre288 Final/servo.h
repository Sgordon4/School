/*
 * servo.h
 *
 *  Created on: Nov 5, 2018
 *      Author: cphilipp
 */

void servo_init();
int turnDegrees(double degrees);

