/*
 * ping.h
 *
 *  Created on: Nov 5, 2018
 *      Author: SGordon4 and cphilipp
 */

volatile char update_flag;
volatile int start_time;
volatile int end_time;
volatile double pulseLength;


void ping_init();
void TIMER3B_Handler();

volatile void sendPulse();

double getPingDistance();
