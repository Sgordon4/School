/*
 * ir.h
 *
 *  Created on: Oct 23, 2018
 *      Author: msolaro
 */

#ifndef IR_H_
#define IR_H_

void ADC_init(void);
int ADC_read(void);
unsigned ADC_read2(char channel);
int IR_Convert(float voltage);

double read_dist2();
double SC_IR_convert(double voltage);
double SCFinal();
//void calibrate(void);

//float voltages[10];
//double distancesCM[10];




#endif /* IR_H_ */
