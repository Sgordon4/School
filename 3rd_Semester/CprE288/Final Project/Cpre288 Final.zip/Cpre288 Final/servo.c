/**
 * servo.c
 *
 *	Used to run the servo for the robot
 *
 *  @author SGordon and cphilipp
 *	@date 11/5/2018
 */

#include "timer.h"
#include "servo.h"

/*
//---------------------------------
void servo_init();
int turnDegrees(double degrees);
//---------------------------------
*/

/**
* This method initializes the servo.
* @author SGordon4, CPhilipp
* @date 11/5/2018
*/
void servo_init()
{
    /*---------------------------------------------------------*/
    /*                   Initializes Timer1B                   */
    /*---------------------------------------------------------*/

    unsigned int period_width = 320000; //clock ticks for 20 ms


    //SYSCTL_RCGCGPIO_R = 0x32;         //Enable port E for buttons
    SYSCTL_RCGCGPIO_R = 0x3F;           //Can't tell what port lcd is on so I just put F (Enables everything)

    GPIO_PORTB_DEN_R |= 0x20;
    GPIO_PORTB_PCTL_R |= 0x700000;
    GPIO_PORTB_AFSEL_R |= 0x20;
    GPIO_PORTB_DIR_R |= 0x20;

    //***set GPIO PB5, turn on clk, alt. function, output, enable***
    SYSCTL_RCGCTIMER_R |= 0x2;                      //Enable clock to GPIO port B
    TIMER1_CTL_R &= ~0x100;                         //disable timer to config
    //-------------------------------------------------------

    TIMER1_TBMR_R &= 0xFFFFF000;                    //Clearing bytes 2:0
    TIMER1_TBMR_R |= 0xA;                           //Setting TBMR configs      0x082A
    // Periodic, edge count, PWM enable, down count, match interupt, drives high on zero

    TIMER1_CFG_R &= 0xFFFFFFF8;                     //Clearing bits 2:0
    TIMER1_CFG_R |= 0x4;                            //Setting timer to 16 bit mode

    TIMER1_TBILR_R = period_width & 0xFFFF;         //lower 16 bits of the interval (set period)
    TIMER1_TBPR_R = period_width >> 16;             //set the upper 8 bits of the interval (time prescalar)

    //TIMER1_TBPMR_R = 0;                             // set match prescaler
    //TIMER1_TBMATCHR_R = 0xFF00;                     // set value for initial interrupt


    TIMER1_ICR_R |= 0x800;                          //clear interrupts
    TIMER1_IMR_R &= 0xFFFEF0E0;                     //Clearing all but RES bits
    TIMER1_IMR_R |= 0x800;                          //enable match interrupts


    TIMER1_TBMATCHR_R = 0x0;

    TIMER1_CTL_R |= 0x100;                           //enable timer
}


/**
* This method turns the servo the specified degrees.
* @author SGordon4, CPhilipp
* @param degrees The degrees to turn
* @date 11/5/2018
*/
int turnDegrees(double degrees){
    unsigned int pulse_width = 0;                    //pulse width in cycles

    //180 degrees is 30,000 ticks: 0 == 283000, 180 = 313000     (using degrees * 150, cant think to see if it matters)
    pulse_width = (int)(degrees * 166.66666666) + 283000;

    TIMER1_TBMATCHR_R = pulse_width & 0x0000FFFF; //set pulse width
    TIMER1_TBPMR_R = pulse_width >> 16;           // set match prescaler

    return 1;
}


