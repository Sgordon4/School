/*
 * movement.c
 *
 *  @author sgordon4, cphilipp, msolaro
 *  @date 10/2/2018
 */

#include "cyBot_uart.h"  // Functions for communiticate between CyBot and Putty (via UART)
#include "open_interface.h"

#include <stdint.h>
#include "timer.h"
#include "lcd.h"
#include <stdbool.h>
#include "driverlib/interrupt.h"

#include "cyBot_uart.h"  // Functions for communiticate between CyBot and Putty (via UART)
// PuTTy: Buad=115200, 8 data bits, No Flow Control, No Party,  COM1
#include "cyBot_Scan.h"  // For scan sensors

//-----------------
void forward(oi_t *sensor_data, int speed, int distance);
void backward(oi_t *sensor_data, int speed, int distance);

void right(oi_t *sensor_data, int speed, int degrees);
void left(oi_t *sensor_data, int speed, int degrees);

void stop();
//-----------------
void testMovement();
//-----------------


#define SNAIL 50    //Usually for testing, won't run away
#define NORMAL_SPEED 150
#define SANIC_SPEED 500

/**
* This method is a quick test to ensure the movement is working as intended
* @author SGordon4, CPhilipp
* @date 10/2/2018
*/

void testMovement(){
    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);

    forward(sensor_data, 200, 500);
    backward(sensor_data, 500,500);

    right(sensor_data, 150, 360);
    left(sensor_data, 150, 360);
    stop();


    /*Ask about how to actually terminate program
    oi_free(sensor_data);
    oi_close();
     */
}

/*------------------------------------------------------------*/


/*-------------------  Movement functions  -------------------*/
/**
* This method moves the robot forward the specified distance.
* @author SGordon4, CPhilipp
* @param sensor_data the sensor data for the robot
* @param speed the speed to set the wheels to, 0-500
* @distance the distance to travel
* @date 11/25/2018
*/
void forward(oi_t *sensor_data, int speed, int distance){
    int sum = 0;

    oi_setWheels(speed, speed);

    while (sum < distance) {
        oi_update(sensor_data);
        sum += sensor_data->distance;
    }
}
/**
* This method moves the robot backward the specified distance.
* @author SGordon4, CPhilipp
* @param sensor_data the sensor data for the robot
* @param speed the speed to set the wheels to, 0-500
* @distance the distance to travel
* @date 11/25/2018
*/
void backward(oi_t *sensor_data, int speed, int distance){
    int sum = 0;
    speed = -speed;
    distance = -distance;

    oi_setWheels(speed, speed);

    while (sum > distance) {
        oi_update(sensor_data);
        sum += sensor_data->distance;
    }
}

/**
* This method turns the robot right the specified distance.
* @author SGordon4, CPhilipp
* @param sensor_data the sensor data for the robot
* @param speed the speed to set the wheels to, 0-500
* @degrees the degrees to turn
* @date 11/25/2018
*/
void right(oi_t *sensor_data, int speed, int degrees){
    int sum = 0;
    degrees = degrees - 6;  //Turns sliiiiightly too far
    degrees = -degrees;

    oi_setWheels(speed * -1, speed);

    while (sum > degrees) {
        oi_update(sensor_data);
        sum += sensor_data->angle;
    }
}
/**
* This method turns the robot left the specified distance.
* @author SGordon4, CPhilipp
* @param sensor_data the sensor data for the robot
* @param speed the speed to set the wheels to, 0-500
* @degrees the degrees to turn
* @date 11/25/2018
*/
void left(oi_t *sensor_data, int speed, int degrees){
    int sum = 0;
    degrees = degrees - 6;  //Turns sliiiiightly too far

    oi_setWheels(speed, speed * -1);

    while (sum < degrees) {
        oi_update(sensor_data);
        sum += sensor_data->angle;
    }
}

void stop(){
    oi_setWheels(0, 0);
}

/*------------------------------------------------------------*/


//------------  Made by msolaro  ------------//
/**
* This method is used to return the values of the cliff sensors to find any immediate drops.
* @author MSolaro
* @param cliffs a char array of length 4 to store the data in
* @date 11/25/2018
*/
void cliffDetector(oi_t *sensor_data, char *cliffs)
{
    short left = 0;
    short frontLeft = 0;
    short frontRight = 0;
    short right = 0;

    oi_update(sensor_data);
    left = sensor_data->cliffLeft;
    frontLeft = sensor_data->cliffFrontLeft;
    frontRight = sensor_data->cliffFrontRight;
    right = sensor_data->cliffRight;

    cliffs[0] = left;
    cliffs[1] = frontLeft;
    cliffs[2] = frontRight;
    cliffs[3] = right;
}
/**
* This method is used to print the values of a cliff sensor array.
* @author SGordon4, CPhilipp
* @param cliffs a char array of length 4 filled with cliff sensor data
* @date 11/25/2018
*/
void printCliffs(char *cliffs){
    int i;
    for(i = 0; i < 4; i++){
        if(cliffs[i])
            cliffs[i] = 'X';
        else
            cliffs[i] = '_';
    }
}

/**
* This method is used to return the values of the cliff sensor�s color detectors.
* @author SGordon4
* @param sensor_data the sensor data of the robot
* @param boundaries an int array of size 4 to store the data 
* @date 11/25/2018
*/
void cliffColorDetector(oi_t *sensor_data, int *boundaries)
{
    int left = 0;
    int frontLeft = 0;
    int frontRight = 0;
    int right = 0;

    oi_update(sensor_data);
    left = sensor_data->cliffLeftSignal;
    frontLeft = sensor_data->cliffFrontLeftSignal;
    frontRight = sensor_data->cliffFrontRightSignal;
    right = sensor_data->cliffRightSignal;

    boundaries[0] = left;
    boundaries[1] = frontLeft;
    boundaries[2] = frontRight;
    boundaries[3] = right;
}

/**
* This method is used to return the values of the bump detectors.
* @author SGordon4
* @param sensor_data the sensor data of the robot
* @param bumpers a char array of size 2 to store the data 
* @date 11/25/2018
*/
void bumpDetector(oi_t *sensor_data, char *bumpers)
{
    char left = 0;
    char right = 0;

    oi_update(sensor_data);
    left = sensor_data->bumpLeft;
    right = sensor_data->bumpRight;

    bumpers[0] = left;
    bumpers[1] = right;
}

