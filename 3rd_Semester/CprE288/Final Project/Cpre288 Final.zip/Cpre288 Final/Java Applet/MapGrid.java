package JavaGUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.util.Arrays;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextField;

//TODO 
/**
 * updateRobit() roomba doesn't really work when not plugged into usb?] i have
 * no idea how to update a spot on this grid
 */
/*
 * What I did
 *
 * degrees now loops 360 => 45 && 0 => 315 degrees now update when turning left
 */
public class MapGrid extends JPanel {
	private static final float FIELD_FONT_SIZE = 15f;
	private static final float ROBIT_FONT_SIZE = 15f;
	private static final int GAP = 3;
	private final int MAP_LENGTH = 51;
	private char[][] map = new char[MAP_LENGTH][MAP_LENGTH];
	private JTextField[][] gridHolder = new JTextField[MAP_LENGTH][MAP_LENGTH];
	private JPanel mainPanel;

	private int degrees = 0; // Degree that the robot is facing. Initially facing 'backwards'

	private Point location = new Point(MAP_LENGTH / 2, MAP_LENGTH / 2);// Robit is located at origin initially
	private char robit = 'r'; // Placeholder used for the robot in map, exchanged in the grid

	public MapGrid() {
		mainPanel = new JPanel(new GridLayout());
		mainPanel.setBorder(BorderFactory.createEmptyBorder(GAP, GAP, GAP, GAP));
		mainPanel.setBackground(Color.BLACK);

		GridLayout grid = new GridLayout(MAP_LENGTH, MAP_LENGTH, 1, 1);
		mainPanel.setLayout(grid);

		int count = 0; // Used to add coloring

		for (int i = 0; i < MAP_LENGTH; i++) {
			count = 0 + i; // Used to add coloring

			// Filling grid with numbering for testing
			// Arrays.fill(map[i], (char)((i%10+48)));

			setMapIndex(location, robit);

			for (int j = 0; j < MAP_LENGTH; j++) {
				JTextField field;
				if (map[i][j] != 'r') {
					field = new JTextField(map[i][j] + "", 1);
					//field = new JTextField("", 1);
					field.setForeground(Color.ORANGE);
					field.setFont(field.getFont().deriveFont(Font.BOLD, FIELD_FONT_SIZE));
				} else {
					field = new JTextField(discernTrueRobit(), 1);
					field.setForeground(Color.ORANGE);
					field.setFont(field.getFont().deriveFont(Font.BOLD, ROBIT_FONT_SIZE));
				}
				field.setHorizontalAlignment(JTextField.CENTER);
				field.setEditable(true); // TODO setEditable false?

				// ---------------- Adding Coloring ----------------\\
				if (count % 2 == 0)
					field.setBackground(Color.WHITE);
				else
					field.setBackground(Color.lightGray);
				count++;

				if (i == MAP_LENGTH / 2 || j == MAP_LENGTH / 2)
					field.setBackground(Color.gray);
				// ---------------------------------------------------\\

				gridHolder[i][j] = field;
				mainPanel.add(field);
			}
		}

		setLayout(new BorderLayout());
		add(mainPanel, BorderLayout.CENTER);
	}

	public static void updateMapSingle(char icon, int relDegree) {

	}

	// Create the icon for the robot, facing in the right direction
	public String discernTrueRobit() {
		String robit = "";

		switch (degrees / 45) {
		case 0:
			robit = "(\u21d1)"; // ^
			break;
		case 1:
			robit = "(\u21d7)";
			break;
		case 2:
			robit = "(\u21d2)"; // >
			break;
		case 3:
			robit = "(\u21d8)";
			break;
		case 4:
			robit = "(\u21d3)"; // \/
			break;
		case 5:
			robit = "(\u21d9)";
			break;
		case 6:
			robit = "(\u21d0)"; // <
			break;
		case 7:
			robit = "(\u21d6)";
			break;
		}

		// TODO make the robot icon look different if faced different direction

		return robit;
	}

	public JPanel getGrid() {
		return mainPanel;
	}

	public char[][] getMap() {
		return map;
	}

	public void setMap(char[][] arr) {
		map = arr;
	}

	public void setMapIndex(int x, int y, char ch) {
		map[x][y] = ch;
	}

	public void setMapIndex(Point point, char ch) {
		map[point.x][point.y] = ch;
	}

	public void setDegrees(int degrees) {
		this.degrees = degrees;
	}

	public int getDegrees() {
		if (degrees >= 360)
			degrees = degrees % 360;
		if (degrees < 0)
			degrees = 360 + degrees;
		return degrees; // degrees will now loop when getDegrees is called
	}

	public void setLocation(int x, int y) {
		location = new Point(x, y);
	}

	public void setLocation(Point location) {
		this.location = location;
	}

	public Point getLocation() {
		return location;
	}

	public double[] getLocationCoordinates() {
		double[] tobeReturned = { 0, 0 };
		tobeReturned[0] = location.getX();
		tobeReturned[1] = location.getY();
		return tobeReturned;
	}

	public void updateRobit(Point loc, int deg) {
		setLocation(loc);
		setDegrees(deg);
		
		JTextField eeee = new JTextField(discernTrueRobit(), 1);
		eeee.setForeground(Color.ORANGE);
		eeee.setFont(eeee.getFont().deriveFont(Font.BOLD, ROBIT_FONT_SIZE));
		
		gridHolder[loc.x][loc.y] = eeee;

	}
}