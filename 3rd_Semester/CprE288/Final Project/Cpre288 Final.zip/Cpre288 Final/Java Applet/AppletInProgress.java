package JavaGUI;

import static javax.swing.GroupLayout.Alignment.BASELINE;
import static javax.swing.GroupLayout.Alignment.CENTER;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

//TODO 
/**
 * when going backwards from a hit needs to only go back to oriiginal spot when
 * reversing diagnal 11cm or up down left right 9 cm Moving forward goes super
 * far?
 */
/*
 * What I did
 *
 * deppending on the degree the robit is facing itll move 11 or 9cm degrees now
 * update when turning left made an array with x,y that updates where the roomba
 * should be going based off when it moves forward at which degree
 *
 */
public class AppletInProgress extends JFrame implements ActionListener, KeyListener {
	private JFrame frame;

	private JButton WButton;
	private JButton AButton;
	private JButton SButton;
	private JButton DButton;

	private JButton scanButton;
	private JTextArea scanResult;

	private JTextArea warningBox;

	private MapGrid mapGrid;
	private JPanel grid;

	private enum Actions {
		FORWARD, LEFT, BACKWARD, RIGHT, SCAN
	}

	private static char[] scanData = new char[180];
	private String warning = "";
	char command = '0';
	char received = '0'; // Used to determine if we hit something

	Socket socket;
	DataOutputStream output;
	DataInputStream input;

	boolean testing = false;

	public AppletInProgress() {
		if (!testing) {
			try {
				socket = new Socket("192.168.1.1", 288);
				System.out.println("connected");
				output = new DataOutputStream(socket.getOutputStream());
				input = new DataInputStream(socket.getInputStream());
			} catch (Exception e) {
			}
		}

		// Arrays.fill(scanData, '_');

		JFrame.setDefaultLookAndFeelDecorated(true);
		frame = new JFrame("GroupLayoutExample Example");
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		frame.addKeyListener(this);
		frame.setFocusable(true);
		frame.setFocusTraversalKeysEnabled(false);

		// ---------------- Create Buttons and Fields ----------------\\

		// JLabel label = new JLabel("");
		// JTextField textField = new JTextField("");
		// JTextField textField = new JTextField("");
		// JButton button = new JButton("");
		// JCheckBox checkBox = new JCheckBox("");
		// checkBox.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

		Dimension buttonSize = new Dimension(40, 40);
		WButton = new JButton("W");
		WButton.setMinimumSize(buttonSize);
		WButton.setActionCommand(Actions.FORWARD.name());
		WButton.addActionListener(this);

		AButton = new JButton("A");
		AButton.setMinimumSize(buttonSize);
		AButton.setActionCommand(Actions.LEFT.name());
		AButton.addActionListener(this);

		SButton = new JButton("S");
		SButton.setMinimumSize(buttonSize);
		SButton.setActionCommand(Actions.BACKWARD.name());
		SButton.addActionListener(this);

		DButton = new JButton("D");
		DButton.setMinimumSize(buttonSize);
		DButton.setActionCommand(Actions.RIGHT.name());
		DButton.addActionListener(this);

		Dimension scanDimensions = new Dimension(scanData.length * 3, 30);
		scanButton = new JButton("Scan");
		scanButton.setMinimumSize(scanDimensions);
		scanButton.setActionCommand(Actions.SCAN.name());
		scanButton.addActionListener(this);

		Dimension scanFieldDimensions = new Dimension(scanData.length * 3, 90);
		scanResult = new JTextArea(printArr(scanData), 8, 25);
		scanResult.setFont(scanResult.getFont().deriveFont(Font.BOLD, 15f));
		scanResult.setMaximumSize(scanFieldDimensions);
		scanResult.setEditable(false);

		Dimension warningDimensions = new Dimension(scanData.length * 3, 30);
		warningBox = new JTextArea(warning, 8, 25);
		warningBox.setFont(scanResult.getFont().deriveFont(Font.BOLD, 20f));
		warningBox.setMaximumSize(warningDimensions);
		warningBox.setEditable(false);
		warningBox.setForeground(Color.RED);

		mapGrid = new MapGrid();
		grid = mapGrid.getGrid();
		grid.setPreferredSize(new Dimension(100, 100));

		// -------------------------------------------------------------\\

		GroupLayout layout = new GroupLayout(frame.getContentPane());
		frame.getContentPane().setLayout(layout);

		layout.setAutoCreateGaps(true);
		layout.setAutoCreateContainerGaps(true);

		// ---------------- Create Structure ----------------\\

		short gapSize = 50;

		layout.setHorizontalGroup(layout.createSequentialGroup()
				.addGroup(layout
						.createParallelGroup(CENTER).addComponent(warningBox).addGap(gapSize).addComponent(scanResult)
						.addComponent(scanButton).addComponent(WButton).addGroup(layout.createSequentialGroup()
								.addComponent(AButton).addComponent(SButton).addComponent(DButton)))
				.addComponent(grid));

		// layout.linkSize(SwingConstants.HORIZONTAL, WButton, AButton, SButton,
		// DButton);

		layout.setVerticalGroup(layout.createParallelGroup(CENTER)
				.addGroup(layout
						.createSequentialGroup().addComponent(warningBox).addGap(gapSize).addComponent(scanResult)
						.addComponent(scanButton).addComponent(WButton).addGroup(layout.createParallelGroup(BASELINE)
								.addComponent(AButton).addComponent(SButton).addComponent(DButton)))
				.addComponent(grid));
		// ----------------------------------------------------\\

		frame.pack();

		// Set window to screen size
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setBounds(0, 0, screenSize.width, screenSize.height);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		command = '0';

		double[] location = { 5, 5 };
		System.arraycopy(mapGrid.getLocationCoordinates(), 0, location, 0, 2);

		try {
			if (e.getActionCommand() == Actions.FORWARD.name()) {
				// JOptionPane.showMessageDialog(null, "Forward");
				// added check if on a diagnol
				if (mapGrid.getDegrees() % 2 == 0)// on diagnal)
				{
					/*
					if (mapGrid.getDegrees() == 0 || mapGrid.getDegrees() == 360) {
						location[1] -= 1;
					} else if (mapGrid.getDegrees() == 180) {
						location[1] += 1;
					} else if (mapGrid.getDegrees() == 270) {
						location[0] += 1;
					} else if (mapGrid.getDegrees() == 90) {
						location[0] -= 1;
					}
					*/
					command = 'F';
				} else {
					/*
					if (mapGrid.getDegrees() == 225) {
						location[0] += 1;
						location[1] += 1;
					} else if (mapGrid.getDegrees() == 315) {
						location[0] += 1;
						location[1] -= 1;
					} else if (mapGrid.getDegrees() == 135) {
						location[0] -= 1;
						location[1] += 1;
					} else if (mapGrid.getDegrees() == 45) {
						location[0] -= 1;
						location[1] -= 1;
					}
					*/

					command = 'f'; // F moves diagnal distance
				}
			} else if (e.getActionCommand() == Actions.LEFT.name()) {
				command = 'l';
			} else if (e.getActionCommand() == Actions.BACKWARD.name()) {
				//command = 'b';	//TODO removing backward functionality because dangerous
			} else if (e.getActionCommand() == Actions.RIGHT.name()) {
				command = 'r';
			} else if (e.getActionCommand() == Actions.SCAN.name()) {
				while (input.available() != 0) {
					input.read();
				} // Clear input JIC
				command = 's';
			}
			// TODO add sections corresponding to other actions

			// JOptionPane.showMessageDialog(null, e.getActionCommand());

			// sets location with new location
			//mapGrid.setLocation((int) location[0], (int) location[1]);

			output.write(command);
			System.out.println("Command " + command + " sent");

			switch (command) {
			case 's':
				char read = '0';
				input.read();

				while (input.available() == 0) {
				} // Wait until there are bytes in stream
				System.out.println("Available: " + input.available());

				byte[] bytes = new byte[180]; // 181 bytes sent

				int oof = input.read(bytes, 0, 99);
				oof += input.read(bytes, 99, 81);

				System.out.println("Available now: " + input.available());

				/*
				 * if(oof != 181) { //Sometimes receives fewer than 181 bytes, usually 99, idk
				 * why //quick not great fix for that, just rescans (0 is an arbitrary number)
				 * actionPerformed(new ActionEvent(scanButton, 0, Actions.SCAN.name())); return;
				 * }
				 */

				System.out.println("Bytes read: " + oof);

				String scan = "";

				for (int i = 0; i < bytes.length; i++) {
					char ch = (char) bytes[i];

					switch (ch) {/*
									 * case '_': scanData[i] = ch; break;
									 */
					case 255:
						continue;
					case 0:
						break;
					default:
						scanData[i] = ch;
						break;
					}
				}

				scan = printScan(scanData);
				scan = scan.substring(0, scan.length() - 7);
				scanResult.setText(scan);
				System.out.println(scan);
				break;
			default:
				received = (char) input.read();
				if((short)received < 11)
					System.out.println("Recieved: " + (short)received);
				else
					System.out.println("Recieved: " + received);
				// for testing purposes
				
				break;
			/*
			 * for(byte b : bytes) { char eeee = (char)b; if(eeee == '_') scan += (char)b;
			 * else if(eeee == 255) continue; //Don't add to str, this is a termination
			 * confirmation char else if(eeee == 0) //null byte break; else scan +=
			 * (short)b+","; }
			 * 
			 * System.out.println(scan); scanData = scan.toCharArray();
			 * scanResult.setText(printArr(scanData)); break; default: received =
			 * (char)input.read(); System.out.println("Recieved: " + received); break;
			 */

			}
			
			
			//Updating position of robot on grid
			//Using 'received' and 'command'
			Point point = mapGrid.getLocation();
			int degree = mapGrid.getDegrees();
			if(received == 'R') {
				if(command == 'f' || command == 'F') {
					switch(mapGrid.getDegrees()) {
					case 0: 
						point.y = point.y+1;
						break;
					case 45: 
						point.x = point.x+1;
						point.y = point.y+1;
						break;
					case 90:
						point.x = point.x+1;
						break;
					case 135:
						point.x = point.x+1;
						point.y = point.y-1;
						break;
					case 180:
						point.y = point.y-1;
						break;
					case 225:
						point.x = point.x-1;
						point.y = point.y-1;
						break;
					case 270:
						point.x = point.x-1;
						break;
					case 315:
						point.x = point.x-1;
						point.y = point.y+1;
						break;
					case 360://JIC
						point.y = point.y+1;
						break;
					}
				}
				
				else if(command == 'l')
					degree = (degree + 360 - 45)%360;
				else if(command == 'r')
					degree = (degree + 360 + 45)%360;
				
				mapGrid.updateRobit(point, degree);
				
				/*
				frame.invalidate();
				frame.validate();
				frame.repaint();
				*/
			}
			System.out.println("Degrees: " + mapGrid.getDegrees());
			

			// while(input.available() != 0) {input.read();}
		} catch (Exception exc) {
			System.out.println("There was an error");
			System.out.println(exc.getMessage());
		}

		// received represents whether or not we hit something and grid should be
		// updated
		if (received > 0 && received < 11) {
			char icon = '0';
			int relDegree = 0;
			String warning = "";
			
			switch ((received - 1) / 4) {

			case 0:
				icon = '#';
				relDegree = received;
				warning = "WARNING: Hole sensor " + relDegree;
				break;
			case 1:
				icon = '+';
				relDegree = received - 4;
				warning = "WARNING: Line sensor " + relDegree;
				break;
			case 2:
				icon = 'O';
				relDegree = received - 8;
				warning = "WARNING: Bump sensor " + relDegree;
				break;
			}
			
			setWarning(warning);
			System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			System.out.println(warning);
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

			MapGrid.updateMapSingle(icon, relDegree);
		}
		// #OI

		/*
		 * frame.invalidate(); frame.validate(); frame.repaint();
		 */
	}

	public static String printArr(char[] arr) {
		String str = "";
		for (int i = 0; i < arr.length; i++) {
			str += arr[i];
			if ((i + 1) % 36 == 0 && i != 0)
				str += "\r\n";
		}

		return str;
	}

	public static String printScan(char[] arr) {
		String[] strArr = { "", "", "", "", "" };
		String str = "";

		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 36; j++) {

				if (arr[i * 36 + j] == '_')
					str = arr[i * 36 + j] + " ";
				else
					str = (short) arr[i * 36 + j] + " "; // ","

				strArr[i] += str;
			}
		}

		str = "";
		for (String s : strArr) {
			str += s + "\r\n";
		}

		return str;
	}

	public void setScanData(char[] arr) {
		scanData = arr;
	}

	public char[] getScanData() {
		return scanData;
	}

	public void setWarning(String warning) {
		this.warning = warning;
	}

	public String getWarning() {
		return this.warning;
	}

	public JFrame getFrame() {
		return frame;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();

		if (key == KeyEvent.VK_W)
			actionPerformed(new ActionEvent(WButton, 0, Actions.FORWARD.name()));
		else if (key == KeyEvent.VK_A)
			actionPerformed(new ActionEvent(AButton, 0, Actions.LEFT.name()));
		else if (key == KeyEvent.VK_S)
			actionPerformed(new ActionEvent(SButton, 0, Actions.BACKWARD.name()));
		else if (key == KeyEvent.VK_D)
			actionPerformed(new ActionEvent(DButton, 0, Actions.RIGHT.name()));
		else if (key == KeyEvent.VK_SPACE)
			actionPerformed(new ActionEvent(scanButton, 0, Actions.SCAN.name()));
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
	}

	public static void main(String[] args) {
		AppletInProgress applet = new AppletInProgress();
		applet.getFrame().setVisible(true);
	}
}
