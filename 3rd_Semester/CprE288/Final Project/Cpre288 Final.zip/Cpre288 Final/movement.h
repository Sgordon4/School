/*
 * movement.h
 *
 *  Created on: Oct 30, 2018
 *      Author: sgordon4 & cphilipp
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "Timer.h"
#include "lcd.h"
#include <inc/tm4c123gh6pm.h>
#include "open_interface.h"

void testMovement();

void forward(oi_t *sensor_data, int speed, int distance);

void backward(oi_t *sensor_data, int speed, int distance);

void right(oi_t *sensor_data, int speed, int degrees);

void left(oi_t *sensor_data, int speed, int degrees);

void stop();

void cliffDetector(oi_t *sensor_data, char *cliffs);
void printCliffs(char *cliffs);

void cliffColorDetector(oi_t *sensor_data, int *boundaries);

void bumpDetector(oi_t *sensor_data, char *bumpers);
