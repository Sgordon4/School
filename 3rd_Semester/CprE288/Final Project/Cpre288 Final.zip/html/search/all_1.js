var searchData=
[
  ['backward',['backward',['../movement_8c.html#a9799804c70b0fa77e7388111531e734f',1,'movement.c']]],
  ['bumpdetector',['bumpDetector',['../movement_8c.html#a52208890fe32afa545d346ad9faf0d8a',1,'movement.c']]]
];
