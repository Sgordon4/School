var searchData=
[
  ['adc_5finit',['ADC_init',['../ir_8c.html#a69f491a768a81c2cf99ee2653ad3002d',1,'ir.c']]],
  ['adc_5fread',['ADC_read',['../ir_8c.html#a5bbea9320798ccfd596c7925f65e7734',1,'ir.c']]],
  ['adc_5fread2',['ADC_read2',['../ir_8c.html#ad70ebc63fb92e75c5feee8da2a2d8cae',1,'ir.c']]]
];
