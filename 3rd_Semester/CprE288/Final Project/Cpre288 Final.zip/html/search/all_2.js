var searchData=
[
  ['checkboundaries',['checkBoundaries',['../main_8c.html#a026c1461c19e6572bab53393ff5d3638',1,'main.c']]],
  ['cliffcolordetector',['cliffColorDetector',['../movement_8c.html#af2917e2d008b6a169dbe4d21dbd285dd',1,'movement.c']]],
  ['cliffdetector',['cliffDetector',['../movement_8c.html#aa56cdc2910ac80862e6d132ceeebb7e6',1,'movement.c']]]
];
