var searchData=
[
  ['sanic_5fspeed',['SANIC_SPEED',['../movement_8c.html#a9b61293bdb7f8b62164e9215973e373f',1,'movement.c']]],
  ['sc_5fir_5fconvert',['SC_IR_convert',['../ir_8c.html#a43815740703219bff680a977bff08baa',1,'ir.c']]],
  ['scan',['scan',['../main_8c.html#a047344685c73aae3707ffbd91c176a4b',1,'main.c']]],
  ['scfinal',['SCFinal',['../ir_8c.html#acd1c306f7f8bbc3e57406bdb603f2242',1,'ir.c']]],
  ['scping_2ec',['SCping.c',['../_s_cping_8c.html',1,'']]],
  ['sendpulse',['sendPulse',['../_s_cping_8c.html#aea545db4b015bcd420060298e4b5a36c',1,'SCping.c']]],
  ['servo_2ec',['servo.c',['../servo_8c.html',1,'']]],
  ['servo_5finit',['servo_init',['../servo_8c.html#a9a6cca57e7cd20ae2ee6d92e289583ae',1,'servo.c']]],
  ['snail',['SNAIL',['../movement_8c.html#a16c904a9bc5ed11d59318cbd6cb82306',1,'movement.c']]],
  ['stop',['stop',['../movement_8c.html#a8c528baf37154d347366083f0f816846',1,'movement.c']]]
];
