var searchData=
[
  ['sanic_5fspeed',['SANIC_SPEED',['../movement_8c.html#a9b61293bdb7f8b62164e9215973e373f',1,'movement.c']]],
  ['snail',['SNAIL',['../movement_8c.html#a16c904a9bc5ed11d59318cbd6cb82306',1,'movement.c']]]
];
