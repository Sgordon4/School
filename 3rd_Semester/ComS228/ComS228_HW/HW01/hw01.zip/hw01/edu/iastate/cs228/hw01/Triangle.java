package edu.iastate.cs228.hw01;


/**
 * @author 
 * 
 *         
 */
 
 
public class Triangle extends GeometricObject
{
	//TODO
	
	
	@Override
	public String toString()
	{
		return "Triangle: side1 = " + side1 + " side2 = " + side2 + " side3 = " + side3;
	}
}
