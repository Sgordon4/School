package edu.iastate.cs228.proj2;


public class FileConfigurationException extends Exception {
	//TODO: implement appropriate message, etc. 

	
}