public class Record {
    String[] value;

    public Record(String[] value){
        this.value = value;
    }
}
