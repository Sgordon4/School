package abstractlang;

public interface Value {
    public String toString();
    static class ZeroVal implements Value {
        public String toString() { 
            return "0";
        }
    }

    static class PositiveVal implements Value {
        public String toString() {
            return "p";
        }
    }

    static class NegativeVal implements Value {
        public String toString() {
            return "n";
        }
    }

    static class UnknownVal implements Value {
        public String toString() {
            return "u";
        }
    }

    static class DynamicError implements Value {
        private String _errorMsg;
        public DynamicError(String v) {
            _errorMsg = v;
        }
        public String v() {
            return _errorMsg;
        }
        public String toString() {
            String tmp = _errorMsg;
            if (tmp == _errorMsg) return "" + tmp;
            return "" + _errorMsg;
        }
    }
}
