package abstractlang;

import static abstractlang.AST.*;
import static abstractlang.Value.*;

public class Evaluator implements Visitor<Value> {
    private ZeroVal record = new ZeroVal();
    Printer.Formatter ts = new Printer.Formatter();
	
    Value valueOf(Program p) {
        // Value of a program in this language is the value of the expression
        return (Value) p.accept(this);
    }
	
    @Override
    public Value visit(AddExp e) {
        Exp lop = e.getLOp();
        Exp rop = e.getROp();

        Value resultLOp = (Value) lop.accept(this);
        Value resultROp = (Value) rop.accept(this);
        if (resultLOp instanceof PositiveVal) {
            if (resultROp instanceof PositiveVal || resultROp instanceof ZeroVal) {
                return new PositiveVal();
            } else {
                return new UnknownVal();
            }
        } else if (resultLOp instanceof NegativeVal) {
            if (resultROp instanceof PositiveVal || resultROp instanceof UnknownVal) {
                return new UnknownVal();
            } else {
                return new NegativeVal();
            }
        } else if (resultLOp instanceof ZeroVal) {
            return resultROp;
        }

        return new UnknownVal();

    }

    @Override
    public Value visit(NumExp e) {
        if (e.v().equals("p")) {
            return new PositiveVal();
        } else if (e.v().equals("n")) {
            return new NegativeVal();
        } else if (e.v().equals("u")) {
            return new UnknownVal();
        }

        return new ZeroVal();
    }

    @Override
    public Value visit(MultExp e) {
        Exp lop = e.getLOp();
        Exp rop = e.getROp();

        Value resultLOp = (Value) lop.accept(this);
        Value resultROp = (Value) rop.accept(this);
        if (resultLOp instanceof ZeroVal || resultROp instanceof ZeroVal) {
            return new ZeroVal();
        } else if (resultLOp instanceof PositiveVal) {
            if (resultROp instanceof NegativeVal) {
                return new NegativeVal();
            } else if (resultROp instanceof PositiveVal) {
                return new PositiveVal();
            } else {
                return new UnknownVal();
            }
        } else if (resultLOp instanceof NegativeVal) {
            if (resultROp instanceof NegativeVal) {
                return new PositiveVal();
            } else if (resultROp instanceof PositiveVal) {
                return new NegativeVal();
            } else {
                return new UnknownVal();
            }
        }

        return new UnknownVal();
    }

    @Override
    public Value visit(Program p) {
        return (Value) p.e().accept(this);
    }

    @Override
    public Value visit(SubExp e) {
        Exp lop = e.getLOp();
        Exp rop = e.getROp();

        Value resultLOp = (Value) lop.accept(this);
        Value resultROp = (Value) rop.accept(this);
        if (resultLOp instanceof ZeroVal) {
            if (resultROp instanceof PositiveVal) {
                return new NegativeVal();
            } else if (resultROp instanceof NegativeVal) {
                return new PositiveVal();
            } else {
                return new UnknownVal();
            }
        } else if (resultLOp instanceof PositiveVal) {
            if (resultROp instanceof PositiveVal || resultROp instanceof UnknownVal) {
                return new UnknownVal();
            } else {
                return new PositiveVal();
            }
        } else if (resultLOp instanceof NegativeVal) {
            if (resultROp instanceof PositiveVal || resultROp instanceof ZeroVal) {
                return new NegativeVal();
            } else {
                return new UnknownVal();
            }
        }

        return new UnknownVal();
    }
}
