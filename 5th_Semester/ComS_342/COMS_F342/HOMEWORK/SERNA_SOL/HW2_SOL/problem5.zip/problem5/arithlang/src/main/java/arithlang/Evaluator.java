package arithlang;
import static arithlang.AST.*;
import static arithlang.Value.*;

import java.util.List;

public class Evaluator implements Visitor<Value> {
    private NumVal record = new NumVal("0");
    Printer.Formatter ts = new Printer.Formatter();

    String add[][] = {{"0","p","n","u"},{"p","p","u","u"},{"n","u","n","u"},{"u","u","u","u"}};
    String mult[][] = {{"0","0","0","0"},{"0","p","n","u"},{"0","n","p","u"},{"0","u","",""}};
    String sub[][] = {{"0","p","n","u"},{"p","u","p","u"},{"n","n","n","n"},{"u","u","u","u"}};

    @Override
    public String toString() {
        return super.toString();
    }

    Value valueOf(Program p) {
        // Value of a program in this language is the value of the expression
        return (Value) p.accept(this);
    }
	
    @Override
    public Value visit(AddExp e) {
        List<Exp> operands = e.all();
        String result;
            NumVal firstch =(NumVal) operands.get(0).accept(this);
            NumVal secondch =(NumVal) operands.get(0).accept(this);

            result = calc("+",firstch.v(),secondch.v());
        return new NumVal(result);
    }

    @Override
    public Value visit(NumExp e) {
        return new NumVal(e.v());
    }



    @Override
    public Value visit(MultExp e) {
        List<Exp> operands = e.all();
        String result;
        NumVal firstch =(NumVal) operands.get(0).accept(this);
        NumVal secondch =(NumVal) operands.get(0).accept(this);

        result = calc("+",firstch.v(),secondch.v());

        return new NumVal(result);
    }

    @Override
    public Value visit(Program p) {
        return (Value) p.e().accept(this);
    }

    @Override
    public Value visit(SubExp e) {
        List<Exp> operands = e.all();

        String result;
        NumVal firstch =(NumVal) operands.get(0).accept(this);
        NumVal secondch =(NumVal) operands.get(0).accept(this);

        result = calc("+",firstch.v(),secondch.v());
        return new NumVal(result);
    }

    public String calc(String operation, String v1, String v2){
        String result; int x, y;

        if(v1.compareTo("0")== 0)
            x=0;
        else if(v1.compareTo("p")== 0)
            x=1;
        else if(v1.compareTo("n")== 0)
            x=2;
        else
            x=3;

        if(v2.compareTo("0")== 0)
            y = 0;
        else if(v2.compareTo("p")== 0)
            y= 1;
        else if(v2.compareTo("n")== 0)
            y=2;
        else
            y = 3;


        if(operation.compareTo("+")== 0)
            result = add[x][y];
        else if(operation.compareTo("-")== 0)
            result = sub[x][y];
        else
            result = mult[x][y];

        return result;
    }
}
