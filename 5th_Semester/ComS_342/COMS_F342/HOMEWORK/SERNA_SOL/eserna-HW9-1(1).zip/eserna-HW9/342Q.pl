mystery([],L2,L2).
mystery([H|Tail], L2,[R|RTail]):-
    H = R,
    mystery(Tail,L2,RTail).

Factorial(0,1).
Factorial(K, R):-
    K > 0,
    K1 = K - 1,
    Factorial(K1, R1),
    R = K * R1.

nextto(X, Y,[X,Y|_]).
    nextto(X, Y,[_|Tail]):-
    nextto(X,Y,Tail).
#part A & B are not complete.
sentence([],[]).
sentence():-

# part c
# the order does matter as it is how the rules for english are.
# If they are changed it is changing how it reads the sentance.


# 4. is not done.
