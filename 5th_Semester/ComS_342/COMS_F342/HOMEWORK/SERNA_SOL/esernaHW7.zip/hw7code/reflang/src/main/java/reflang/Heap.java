package reflang;

public interface Heap {

    public Value ref (Value v);
    public Value deref(Value.RefVal r);
    public Value setref(Value.RefVal r, Value v);
    public Value free (Value.RefVal r);

    public class Heap16Heap {
        Value[] _rep = new Value[65536];

        public Value ref(Value val) {
            for(int i = 0; i < _rep.length;i++){
                if (_rep[i] == null) {
                    _rep[i] = val;
                    return new Value.RefVal(i);
                }
            }

            return val;
        }

        public Value deref(Value.RefVal r) {
            return _rep[r.v()];
        }
        public Value setref(Value.RefVal loc, Value val){
            _rep[loc.v()] = val;
            return val;
        }
        public Value free(Value.RefVal loc){
            _rep[loc.v()] = null;
            return loc;
        }
    }
}
