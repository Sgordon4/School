package coms342;

public class Operations {

    public int plus(int op1, int op2) {
        return op1 + op2;
    }

    public int minus(int op1, int op2) {
        return op1 - op2;
    }
}
